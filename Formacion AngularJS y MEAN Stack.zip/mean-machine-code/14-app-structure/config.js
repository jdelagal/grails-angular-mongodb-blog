module.exports = {
	'port': process.env.PORT || 8080,
	'database': 'mongodb://node:noder@novus.modulusmongo.net:27017/Iganiq8o',
	'secret': 'ilovescotchscotchyscotchscotch'
};