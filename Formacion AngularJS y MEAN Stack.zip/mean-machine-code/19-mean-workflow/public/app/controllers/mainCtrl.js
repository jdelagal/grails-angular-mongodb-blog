angular.module('mainCtrl', [])

.controller('mainController', function() {
	var vm = this;	
	vm.message = 'this is my message!';
});