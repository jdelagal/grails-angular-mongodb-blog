cursoangularjs
==============

Codigo fuente del curso de Curso de AngularJS y REST con Java y Spring en http://www.cursoangularjs.es/doku.php

Hay que tener en cuenta que cada carpeta del repositorio es un ejemplo distinto y NO una capa de una aplicación.
