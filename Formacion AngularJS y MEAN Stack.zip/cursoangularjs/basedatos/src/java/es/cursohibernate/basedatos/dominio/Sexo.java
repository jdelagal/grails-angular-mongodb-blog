package es.cursohibernate.basedatos.dominio;

public enum Sexo {
    H, M;
}
