package es.cursohibernate.seguros.dominio;

public enum Sexo {
    H, M;
}
